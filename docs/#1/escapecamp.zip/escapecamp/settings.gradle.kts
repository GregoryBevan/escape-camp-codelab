rootProject.name = "escapecamp"
