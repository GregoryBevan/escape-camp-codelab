package me.elgregos.escapecamp

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class EscapecampApplicationTests {

	@Test
	fun contextLoads() {
	}

}
